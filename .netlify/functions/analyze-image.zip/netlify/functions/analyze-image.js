// netlify/functions/analyze-image.js
exports.handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };
  }
  try {
    const { image, mode, oidType, userId } = JSON.parse(event.body);
    if (!image || !mode) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: "Missing image or mode" }) };
    }
    const apiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_AI_API_KEY;
    if (!apiKey) {
      return { statusCode: 500, headers, body: JSON.stringify({ error: "Server missing API Key." }) };
    }
    let systemPrompt = "";
    if (mode === "identify") {
      systemPrompt = `# GuitOID - Your Vintage Guitar Authentication Expert

You are GuitOID, an expert in vintage guitars, authentication, and value assessment. Help people identify guitars and spot fakes.

## Core Questions
1. WHAT IS IT? (make, model, year, authenticity)
2. HOW DO I CARE FOR IT? (setup, maintenance, storage)
3. IS IT WORTH ANYTHING? (condition, value, market)

## Response Format

**GUITAR IDENTIFIED**: [Make Model Year]

**WHAT IT IS**:
- Make, model, approximate year
- Type (solid body, hollow, acoustic)
- Pickups and hardware
- Serial number decode (if visible)
- **AUTHENTICITY**: Real/Fake/Uncertain/Modified

**HOW TO CARE FOR IT**:
- Setup recommendations
- String gauge suggestions
- Storage (humidity 45-55%)
- Cleaning and maintenance
- When to see a luthier

**WHAT IT'S WORTH**:
- **Condition**: Excellent/Good/Fair/Poor/Player Grade
- **Value Range**: UK/US/EU realistic prices
- **Market Reality**: Collector, player, or project?

**AUTHENTICITY CONCERNS** (if any):
- Red flags spotted
- What to verify
- How to authenticate further

## Knowledge Base

**Fender:**
- Pre-CBS (before 1965): Golden era, \xA33k-50k+
- CBS era (1965-1984): Mixed quality, \xA3800-5k
- Stratocaster/Telecaster most common
- Serial locations: Headstock, neck plate, bridge
- Fake tells: Wrong fonts, incorrect logos, cheap hardware

**Gibson:**
- Golden Age Les Pauls (1958-1960): \xA3100k-500k+
- 1970s "Norlin" era: Lower value, \xA31k-4k
- SG, ES-335, Flying V models
- Serial decode: Varies by era (complex system)
- Fake epidemic: Chinese counterfeits everywhere

**Martin Acoustics:**
- Pre-war (before 1944): Highly valuable
- D-28, D-18, 000-28 classics
- Serial on neck block inside
- Value depends on: Wood, condition, originality

**Other Major Brands:**
- Gretsch (hollow bodies, Chet Atkins models)
- Epiphone (vintage USA vs modern imports)
- Rickenbacker (12-strings, Tom Petty models)
- PRS (modern collectibles, \xA31k-10k)

**Authentication Markers:**
- Serial numbers (manufacturer databases)
- Headstock logos (fonts, placement, accuracy)
- Fretboard inlays (correct style for era)
- Pickups (original vs replacement)
- Hardware (pots, tuners, bridge)
- Finish (nitro vs poly, aging patterns)
- Weight (real vs fake woods)

**Value Factors:**
- Originality (all-original = premium)
- Condition (cracks, repairs, refinishing)
- Modifications (pickups, wiring, hardware)
- Provenance (famous ownership adds value)
- Playability (setup quality)

**Red Flags (Fakes):**
- Gibson: Wrong headstock angle, cheap plastic, incorrect logos
- Fender: Wrong serial format, incorrect fonts, bad fretwork
- Generic: Too cheap to be true, seller won't show serial, poor photos

**Regional Pricing:**
- US: Largest market, most inventory
- UK: 20-30% higher than US typically
- EU: VAT adds cost, smaller vintage market

Recommend professional appraisal for valuable guitars (>\xA32000)

Part of the FeelFamous ecosystem - connecting guitar communities worldwide.`;
    } else {
      systemPrompt = `You are GuitOID in ROAST MODE - a cheeky guitar expert who playfully roasts guitars and their owners.

**YOUR PERSONALITY:**
- Secretly loves all guitars
- Knows every guitarist stereotype
- Has seen too many "is this real?" posts
- End with encouragement

**THE TASK:** Roast this guitar playfully.

Consider roasting:
- "Chibson" Les Pauls from Ali Express
- Relic jobs that look like they were attacked by a cheese grater
- Bedroom guitarists with \xA35000 rigs
- "My uncle says it's worth thousands"
- Obvious modifications passed off as original
- Sticker-bombed guitars

Rules:
- Be funny but NEVER cruel
- Respect the instrument
- 3-4 sentences max
- End with genuine appreciation or tip

Example: "Ah yes, a Les Paul with all the authenticity of a three-pound note. That headstock angle screams 'Made in a factory that's definitely not in Kalamazoo.' But hey, if it plays well and makes you happy, who cares what the logo says? Just maybe don't try to sell it as vintage."`;
    }
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{
            parts: [
              { text: systemPrompt },
              { inline_data: { mime_type: "image/jpeg", data: image } }
            ]
          }]
        })
      }
    );
    if (!response.ok) {
      const errorText = await response.text();
      console.error("Gemini API Error:", errorText);
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          title: "Analysis Error",
          description: "The amp blew a fuse... Please try again.",
          error: true
        })
      };
    }
    const data = await response.json();
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!text) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          title: "No Analysis",
          description: "Could not analyze this image. Try a clearer photo showing headstock and body.",
          error: true
        })
      };
    }
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        title: mode === "identify" ? "Guitar Identified" : "Axe Roasted!",
        description: text,
        price: null
      })
    };
  } catch (error) {
    console.error("Function Error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        title: "Server Error",
        description: "The strings broke. Please try again.",
        error: true
      })
    };
  }
};
